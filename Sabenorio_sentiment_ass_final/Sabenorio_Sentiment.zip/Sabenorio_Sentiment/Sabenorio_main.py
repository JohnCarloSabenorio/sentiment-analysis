import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score 
import joblib
import nltk
from nltk.corpus import stopwords
import re
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE
import string

# Download the stopwords library
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Load data from CSV
def load_data(path):
    data = pd.read_csv(path)
    return data[['Review', 'Rating']]

def preprocess_data(data):
    # Convert to lowercase
    data['Review'] = data['Review'].str.lower()
    
    # Remove special characters
    data['Review'] = data['Review'].apply(lambda x: re.sub(r'[^a-z\s]', '', x))
    
    # Remove stopwords
    data['Review'] = data['Review'].apply(lambda x: ' '.join(word for word in x.split() if word not in stop_words))
    # data['Rating'] = data['Rating'].apply(lambda x: 1 if x > 3 else 0)
    return data
    
def train_model(data):
    X = data['Review']
    y = data['Rating']
    
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    # Create the TF-IDF vectorizer
    vectorizer = TfidfVectorizer(ngram_range=(1, 4), max_features=50000)
    X_train_tfidf = vectorizer.fit_transform(X_train)

    # Resample data
    smote = SMOTE(random_state=42)
    X_resampled, y_resampled = smote.fit_resample(X_train_tfidf, y_train)

    # Create the model
    model = LinearSVC()
    model.fit(X_resampled, y_resampled)

    # Cross-validation scores
    cross_val_scores = cross_val_score(model, X_resampled, y_resampled, cv=5, scoring='accuracy')

    # Evaluate on the test set
    X_test_tfidf = vectorizer.transform(X_test)
    predictions = model.predict(X_test_tfidf)
    print(f"Model Accuracy: {accuracy_score(y_test, predictions):.2f}")

    # Save the model and the vectorizer to files
    joblib.dump(model, 'sentiment_model.pkl')
    joblib.dump(vectorizer, 'tfidf_vectorizer.pkl')
    print("Sentiment model and vectorizer were created.")
    
    return model, vectorizer, cross_val_scores

def predict_rating(model, vectorizer, user_review):
    # Preprocess the user review
    user_review = user_review.lower()
    user_review = re.sub(r'[^a-z\s]', '', user_review)
    user_review = ' '.join(word for word in user_review.split() if word not in stop_words)

    # Transform the user review using the fitted vectorizer
    user_review_tfidf = vectorizer.transform([user_review])  # Note the list
    prediction = model.predict(user_review_tfidf)
    return prediction[0]

def plot_accuracy(cross_val_scores):
    plt.figure(figsize=(8, 6))
    plt.plot(range(1, len(cross_val_scores) + 1), cross_val_scores, marker='o', linestyle='-', color='b')
    plt.title('Spotify Model Accuracy by John Carlo Sabenorio', fontsize=16)
    plt.xlabel('Fold', fontsize=12)
    plt.ylabel('Accuracy', fontsize=12)
    plt.ylim(0, 1)
    plt.grid(True)
    plt.savefig('Accuracy_Sabenorio.jpg')  # Save the figure
    plt.show()

# Main execution
file = 'spotify_reviews.csv'
data = load_data(file)
pre_data = preprocess_data(data)

# Train the model
# model, vectorizer, cross_val_scores = train_model(pre_data)


# Example user review for prediction
user_review1 = "Spotify's features are great, but I wish there was more customization for playlists."
user_review2 = 'The platform is reliable for mainstream music, but the interface can be frustrating.'
user_review3 = "Spotify has transformed my music listening with fantastic playlists and personalized recommendations. The premium version is worth every penny!"
user_review4 = "The premium subscription feels overpriced given the app's issues and repetitive recommendations"
user_review5 = "The premium service isn't worth it; the bugs and playback issues are infuriating, so I'm canceling."

user_review1 = "Spotify's features are great, but I wish there was more customization for playlists."
user_review2 = 'The platform is reliable for mainstream music, but the interface can be frustrating.'
user_review3 = "Spotify has transformed my music listening with fantastic playlists and personalized recommendations. The premium version is worth every penny!"
user_review4 = "The premium subscription feels overpriced given the app's issues and repetitive recommendations"
user_review5 = "The premium service isn't worth it; the bugs and playback issues are infuriating, so I'm canceling."

user_review6 = "The app crashes constantly, and I'm fed up with disappearing playlists and unbearable ads."
user_review7 = "It has a decent library, but the app can be sluggish and has syncing issues."
user_review8 = "I love Spotify for its diverse playlists and podcasts-Discover Weekly always introduces me to new favorites!"
user_review9 =  "Great music selection, but the app's performance has really declined with constant glitches."
user_review10 = "The music selection is excellent, but the recommendations can sometimes miss the mark."
model = joblib.load('sentiment_model.pkl')
vectorizer = joblib.load('tfidf_vectorizer.pkl')

predicted_rating1 = predict_rating(model, vectorizer, user_review1) 
predicted_rating2 = predict_rating(model, vectorizer, user_review2) 
predicted_rating3 = predict_rating(model, vectorizer, user_review3) 
predicted_rating4 = predict_rating(model, vectorizer, user_review4) 
predicted_rating5 = predict_rating(model, vectorizer, user_review5) 
predicted_rating6 = predict_rating(model, vectorizer, user_review6) 
predicted_rating7 = predict_rating(model, vectorizer, user_review7) 
predicted_rating8 = predict_rating(model, vectorizer, user_review8) 
predicted_rating9 = predict_rating(model, vectorizer, user_review9) 
predicted_rating10 = predict_rating(model, vectorizer, user_review10) 

# Display results
print("Sample Prediction of User Review 1:", user_review1, "\nPredicted Rating:", predicted_rating1) # correct
print("Sample Prediction of User Review 2:", user_review2, "\nPredicted Rating:", predicted_rating2) # wrong
print("Sample Prediction of User Review 3:", user_review3, "\nPredicted Rating:", predicted_rating3) # correct
print("Sample Prediction of User Review 4:", user_review4, "\nPredicted Rating:", predicted_rating4) # wrong
print("Sample Prediction of User Review 5:", user_review5, "\nPredicted Rating:", predicted_rating5) # correct
print("Sample Prediction of User Review 6:", user_review6, "\nPredicted Rating:", predicted_rating6) # correct
print("Sample Prediction of User Review 7:", user_review7, "\nPredicted Rating:", predicted_rating7) # correct
print("Sample Prediction of User Review 8:", user_review8, "\nPredicted Rating:", predicted_rating8) # correct
print("Sample Prediction of User Review 9:", user_review9, "\nPredicted Rating:", predicted_rating9) # wrong
print("Sample Prediction of User Review 10:", user_review10, "\nPredicted Rating:", predicted_rating10) # correct


# plot_accuracy(cross_val_scores)

